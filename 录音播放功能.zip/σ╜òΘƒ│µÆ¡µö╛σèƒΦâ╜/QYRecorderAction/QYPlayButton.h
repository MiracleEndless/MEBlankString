//
//  QYPlayButton.h
//  RecorderAndPlay
//
//  Created by 蓝科 on 16/5/18.
//  Copyright © 2016年 千羽. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QYPlayButton : UIButton
//动画时间间隔属性
@property (nonatomic, assign) NSTimeInterval duration;

//开始动画
- (void)startAnimating;
//停止动画
- (void)stopAnimating;
@end
