//
//  QYRecorderView.h
//  RecorderAndPlay
//
//  Created by 蓝科 on 16/5/17.
//  Copyright © 2016年 千羽. All rights reserved.
//

#import <UIKit/UIKit.h>
@class QYRecorderView;

//设置协议
@protocol QYRecorderViewDelegate <NSObject>

//将录音界面的持续时间传入播放界面
- (void)recorderView:(QYRecorderView *)recorderView didRecorderFinishedWithDuration:(NSTimeInterval)duration;

@end
@interface QYRecorderView : UIView

@property (nonatomic, strong) NSString *tempPath;//录音存储路径
@property (nonatomic, weak) id<QYRecorderViewDelegate> delegate;

//显示录音界面
- (void)show;

//隐藏录音界面
- (void)hide;
@end
