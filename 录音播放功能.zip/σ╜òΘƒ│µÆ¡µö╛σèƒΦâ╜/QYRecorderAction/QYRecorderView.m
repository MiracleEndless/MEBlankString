//
//  QYRecorderView.m
//  RecorderAndPlay
//
//  Created by 蓝科 on 16/5/17.
//  Copyright © 2016年 千羽. All rights reserved.
//

#import "QYRecorderView.h"
#import <AVFoundation/AVFoundation.h>

#define kDuration 0.25f
#define kLightBlackColor [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3]

@interface QYRecorderView ()

@property (nonatomic, strong) UIImageView *microphone;//麦克风
@property (nonatomic, strong) UIImageView *microphoneInside;//麦克风内部视图
@property (nonatomic, strong) AVAudioRecorder *recorder;//录音器

@property (nonatomic, strong) NSDictionary *recoderSetting;//录音参数配置
@property (nonatomic, strong) NSTimer *timer;

@end

@implementation QYRecorderView

#pragma mark - 懒加载
- (UIImageView *)microphone
{
    if (_microphone == nil) {
        UIImage *image = [UIImage imageNamed:@"lp_microphone"];
        _microphone = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
        _microphone.image = image;
        
        CGPoint center = self.center;
        center.y -= 100;
        _microphone.center = center;
    }
    return _microphone;
}

- (UIImageView *)microphoneInside
{
    if (_microphoneInside == nil) {
        UIImage *image = [UIImage imageNamed:@"lp_microphone_inside1"];
        _microphoneInside = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
        //设置麦克风内部跳动颜色的中心点
        _microphoneInside.center = CGPointMake(self.microphone.bounds.size.width/2.0, self.microphone.bounds.size.height/2.0-10);
        _microphoneInside.image = image;
    }
    return _microphoneInside;
}

- (NSString *)tempPath
{
    NSLog(@"沙盒路径 %@",NSHomeDirectory());
    if (_tempPath == nil) {
        //获取沙盒中的Document文件路径
        NSArray *array = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentPath = array.firstObject;
        
        //在Document文件夹下再拼接一个文件夹TempPath的路径
        _tempPath = [documentPath stringByAppendingPathComponent:@"TempPath"];
        
        //判断TempPath文件夹是否存在 如果不存在就在创建一个
        if (![[NSFileManager defaultManager] fileExistsAtPath:_tempPath]) {
            [[NSFileManager defaultManager] createDirectoryAtPath:_tempPath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        //在TempPath文件夹下面拼接一个tempAudio.m4a的路径
        _tempPath = [_tempPath stringByAppendingPathComponent:@"tempAudio.m4a"];
    }
    return _tempPath;
}

- (NSDictionary *)recoderSetting
{
    if (_recoderSetting == nil) {
        _recoderSetting = [NSDictionary dictionaryWithObjectsAndKeys:
                           [NSNumber numberWithInt:kAudioFormatMPEG4AAC],AVFormatIDKey,
                           [NSNumber numberWithInt:1],AVNumberOfChannelsKey,
                           [NSNumber numberWithInt:AVAudioQualityMin],AVEncoderAudioQualityKey,
                           [NSNumber numberWithInt:AVAudioQualityMin],AVSampleRateConverterAudioQualityKey,
                           [NSNumber numberWithInt:8],AVLinearPCMBitDepthKey,
                           [NSNumber numberWithInt:8],AVEncoderBitDepthHintKey,
                           nil];
    }
    return _recoderSetting;
}

- (AVAudioRecorder *)recorder
{
    if (_recorder == nil) {
        NSURL *url = [NSURL fileURLWithPath:self.tempPath];
        _recorder = [[AVAudioRecorder alloc] initWithURL:url settings:self.recoderSetting error:nil];
        //开启测量
        _recorder.meteringEnabled = YES;
    }
    return _recorder;
}
//重写frame的setter
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor lightGrayColor];
        //将microphone添加到RecorderView上
        [self addSubview:self.microphone];
        //将麦克风内部颜色添加到麦克风上
        [self.microphone addSubview:self.microphoneInside];
    }
    return self;
}

//显示录音界面
- (void)show
{
    //创建一个主window
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    [keyWindow addSubview:self];
    
    self.backgroundColor = [UIColor clearColor];
    //显示动画
    [UIView animateWithDuration:kDuration animations:^{
        self.backgroundColor = kLightBlackColor;
    } completion:^(BOOL finished) {
        //开始录音
        [self startRecordering];
    }];
}

//隐藏录音界面
- (void)hide
{
    //把录音时长传给代理
    if ([self.delegate respondsToSelector:@selector(recorderView:didRecorderFinishedWithDuration:)]) {
        [self.delegate recorderView:self didRecorderFinishedWithDuration:self.recorder.currentTime];
    }

    //录音结束
    [self stopRecordering];
    
    self.backgroundColor = kLightBlackColor;
    [UIView animateWithDuration:kDuration animations:^{
        self.backgroundColor = [UIColor clearColor];
    } completion:^(BOOL finished) {
        //将self从keyWindow中移除
        [self removeFromSuperview];
    }];
}

//开始录音
- (void)startRecordering
{
    //准备录音
    [self.recorder prepareToRecord];
    //录音
    [self.recorder record];
    
    //启动定时器
    self.timer = [NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(listenAveragePower) userInfo:nil repeats:YES];
    
//#warning 7.0以上真机测试需要添加的
    //真机测试解决无法录音
    if ([[[UIDevice currentDevice] systemVersion] compare:@"7.0"] != NSOrderedAscending)
    {
        //7.0第一次运行会提示，是否允许使用麦克风
        AVAudioSession *session = [AVAudioSession sharedInstance];
        NSError *sessionError;
        //AVAudioSessionCategoryPlayAndRecord用于录音和播放
        [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&sessionError];
        if(session == nil)
            NSLog(@"Error creating session: %@", [sessionError description]);
        else
            [session setActive:YES error:nil];
    }

}

//结束录音
- (void)stopRecordering
{
    //录音结束
    [self.recorder stop];
    //关闭定时器
    [self.timer invalidate];
}

//监听录音的平均功率
- (void)listenAveragePower
{
    [self.recorder updateMeters];
    
    //获取录音的平均功率
    CGFloat averagePower = [self.recorder averagePowerForChannel:0];
    NSLog(@"averagePower = %f",averagePower);
    
    //根据平均功率来获取当前图片的索引
    int imageIndex;
    if (averagePower<= - 50.543) {
        imageIndex = 1;
    } else if ( - 50.543 <averagePower && averagePower<= - 46.686) {
        imageIndex = 1;
    } else if ( - 46.686 <averagePower && averagePower<= - 42.829) {
        imageIndex = 1;
    } else if ( - 42.829 <averagePower && averagePower<= - 38.982) {
        imageIndex = 1;
    } else if ( - 38.982 <averagePower && averagePower<= - 35.135) {
        imageIndex = 2;
    } else if ( - 35.135 <averagePower && averagePower<= - 31.288) {
        imageIndex = 3;
    } else if ( - 31.288 <averagePower && averagePower<= - 27.441) {
        imageIndex = 4;
    } else if ( - 27.441 <averagePower && averagePower<= - 23.594) {
        imageIndex = 5;
    } else if ( - 23.594 <averagePower && averagePower<= - 19.747) {
        imageIndex = 6;
    } else if ( - 19.747 <averagePower && averagePower<= - 15.900) {
        imageIndex = 7;
    } else if ( - 15.900 <averagePower && averagePower<= - 12.053) {
        imageIndex = 8;
    } else if ( - 12.053 <averagePower && averagePower<= - 8.206) {
        imageIndex = 9;
    } else if ( - 8.206 <averagePower && averagePower<= - 4.359) {
        imageIndex = 9;
    } else if ( - 4.359 <averagePower && averagePower<= 0) {
        imageIndex = 9;
    } else {
        imageIndex = 9;
    }
    
    UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"lp_microphone_inside%d",imageIndex]];
    //将麦克风里面的颜色 设置为获取的当前平均功率所对应的索引图片
    self.microphoneInside.image = image;
}
@end






